<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Вход | Faberlic</title>
  <style>
    body {
      background: #f8e1ed;
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    form {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      width: 400px;
    }
    h2 {
      text-align: center;
      color: #d63384;
    }
    label {
      display: block;
      margin-top: 15px;
      color: #333;
    }
    input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    button {
      margin-top: 20px;
      width: 100%;
      background: #d63384;
      color: white;
      border: none;
      padding: 12px;
      font-size: 16px;
      border-radius: 6px;
      cursor: pointer;
    }
    button:hover {
      background: #c2185b;
    }
  </style>
</head>
<body>
  <form action="auth.php" method="POST">
    <h2>Вход в личный кабинет</h2>
    <label>Email: <input type="email" name="email" required></label>
    <label>Пароль: <input type="password" name="password" required></label>
    <button type="submit">Войти</button>
  </form>
</body>
</html>
