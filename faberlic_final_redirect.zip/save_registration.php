<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $surname = $_POST["surname"];
  $name = $_POST["name"];
  $patronymic = $_POST["patronymic"];
  $dob = $_POST["dob"];
  $city = $_POST["city"];
  $phone = $_POST["phone"];
  $email = $_POST["email"];
  $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
  $id = uniqid("user_");

  $row = [$id, $surname, $name, $patronymic, $dob, $city, $phone, $email, $password, date("Y-m-d H:i:s")];

  $file = fopen("users.csv", "a");
  fputcsv($file, $row);
  fclose($file);

  header("Location: https://tilda.cc/page/?pageid=71972601&projectid=13859235");
  exit;
}
?>