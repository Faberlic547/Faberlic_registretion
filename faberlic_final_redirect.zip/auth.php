<?php
session_start();

$email = $_POST["email"];
$password = $_POST["password"];

if (($handle = fopen("users.csv", "r")) !== FALSE) {
  while (($data = fgetcsv($handle)) !== FALSE) {
    if ($data[7] === $email && password_verify($password, $data[8])) {
      $_SESSION["user"] = [
        "id" => $data[0],
        "surname" => $data[1],
        "name" => $data[2],
        "patronymic" => $data[3],
        "dob" => $data[4],
        "city" => $data[5],
        "phone" => $data[6],
        "email" => $data[7],
        "reg_date" => $data[9]
      ];
      fclose($handle);
      header("Location: https://tilda.cc/page/?pageid=71972601&projectid=13859235");
      exit;
    }
  }
  fclose($handle);
}

echo "Неверный логин или пароль.";
?>